#!/bin/bash
#  Create a SSL Client certificate
USAGE="Usage: genClient.sh name password, please check your params!"
if [ -z "$1" ] || [ -z "$2" ]; then
    echo ${USAGE}
    exit 0
fi

user="$1"
pass="$2"
CLIENT_SUBJ="$3"
#CLIENT_SUBJ="/C=CN/ST=HN/L=CS/O=Hnebang/OU=CSWJ/CN=cswj."$user"@hnebang.com"

echo "generating certficate for user: "$user" with password: "$pass

openssl genrsa -des3 -passout pass:"$pass" -out private/client-"$user".key 2048

openssl rsa -passin pass:"$pass" -in private/client-"$user".key -out private/client-"$user".key

echo "key file created: private/client-"$user".key"

openssl req -config openssl.cnf -new -sha256 -subj $CLIENT_SUBJ -key private/client-"$user".key -out csr/client-"$user".csr

echo "request file created: csr/client-"$user".csr"

openssl ca -batch -config openssl.cnf -days 3650 -in csr/client-"$user".csr -out certs/client-"$user".crt -keyfile private/rootCA.key -cert certs/rootCA.crt -policy policy_anything

echo "certificate file created: certs/client-"$user".crt"

openssl pkcs12 -export -passout pass:"$pass" -in certs/client-"$user".crt -inkey private/client-"$user".key -certfile certs/rootCA.crt -caname "Client" -out certs/client"$user".p12

echo "pks12 file created: certs/client-"$user".p12"

openssl ca -config openssl.cnf -keyfile private/rootCA.key -cert certs/rootCA.crt -gencrl -out ca-crl.pem

echo "updated crl file"
echo "Done!!"
